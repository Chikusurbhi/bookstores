package com.cg.service;

import java.util.List;

import com.cg.model.Book;
import com.cg.model.Category;

public interface ICategoryService {
	public List<Book> findByCategoryName(String categoryName);
	public Category save(Category category);
}
