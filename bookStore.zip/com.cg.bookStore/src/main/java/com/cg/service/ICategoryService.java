package com.cg.service;

import java.util.List;

import com.cg.model.Book;

public interface ICategoryService {
	public List<Book> findByCategoryName(String categoryName);
}
