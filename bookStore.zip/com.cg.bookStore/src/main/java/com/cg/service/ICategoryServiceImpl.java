package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICategoryDao;
import com.cg.model.Book;

@Service
public class ICategoryServiceImpl  implements ICategoryService{
	
	@Autowired
	ICategoryDao iCategoryDao;

	@Override
	public List<Book> findByCategoryName(String categoryName) {
		// TODO Auto-generated method stub
		return iCategoryDao.findByCategoryName(categoryName);
	}
	
}
