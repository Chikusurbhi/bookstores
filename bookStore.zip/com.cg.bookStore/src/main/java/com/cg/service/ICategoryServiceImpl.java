package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICategoryDao;
import com.cg.model.Book;
import com.cg.model.Category;

@Service("iCategoryService")
public class ICategoryServiceImpl  implements ICategoryService{
	
	@Autowired
	ICategoryDao iCategoryDao;

	@Override
	public List<Book> findByCategoryName(String categoryName) {
		// TODO Auto-generated method stub
		List<Book> list=iCategoryDao.findByCategoryName(categoryName);
		
		if(list.get(0)!=null) {
			return list;
		}
		else {
			return list;}
		
	}
	
	public Category save(Category category) {
		return iCategoryDao.save(category);
	}
	
	
}
