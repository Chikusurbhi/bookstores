package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IOrderDao;
import com.cg.model.Customer;
import com.cg.model.Order;

@Service
public class IOrderServiceImpl  implements IOrderService{

	@Autowired
	IOrderDao iOrderDao;

	@Override
	public Order findByOrderId(int orderId) {
		// TODO Auto-generated method stub
		return iOrderDao.findByOrderId(orderId);
	}

	@Override
	public Order findByCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return iOrderDao.findByCustomer(customer);
	}
}
