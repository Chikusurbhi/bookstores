package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IAdminDao;
import com.cg.model.Admin;

@Service
public class IAdminServiceImpl implements IAdminService{

	@Autowired
	IAdminDao iAdminDao;

	@Override
	public Admin findByEmail(String email) {
		// TODO Auto-generated method stub
		return iAdminDao.findByEmail(email);
	}
	
	
}
