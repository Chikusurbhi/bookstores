package com.cg.service;

import com.cg.model.Book;
import com.cg.model.Customer;
import com.cg.model.Review;

public interface IReviewService {

     public Review findByBook(Book book);
	
	public Review findByCustomer(Customer customer);
	
	public Review save(Review review);
}
