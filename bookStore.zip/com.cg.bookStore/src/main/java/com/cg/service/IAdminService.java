package com.cg.service;

import com.cg.model.Admin;

public interface IAdminService {
	public Admin findByEmail(String email);
	public Admin save(Admin admin);
}
