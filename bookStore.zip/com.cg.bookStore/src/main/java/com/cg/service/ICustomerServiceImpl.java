package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDao;
import com.cg.model.Customer;

@Service
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao iCustomerDao;

	@Override
	public Customer findByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return iCustomerDao.findByCustomerId(customerId);
	}

	@Override
	public Customer findByEmailId(String emailId) {
		// TODO Auto-generated method stub
		return iCustomerDao.findByEmailId(emailId);
	}
}
