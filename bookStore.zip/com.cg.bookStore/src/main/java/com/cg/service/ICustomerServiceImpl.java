package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDao;
import com.cg.model.Customer;

@Service("iCustomerService")
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao iCustomerDao;

	@Override
	public Customer findByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		Customer customer=iCustomerDao.findByCustomerId(customerId);
		if(customer!=null) {
			return customer;
		}else {
			return customer;
		}
	}

	@Override
	public Customer findByEmailId(String emailId) {
		// TODO Auto-generated method stub
		Customer customer= iCustomerDao.findByEmailId(emailId);
		if(customer!=null) {
			return customer;
		}else {
			return customer;
		}
	}
	
	
	public Customer save(Customer customer) {
		return iCustomerDao.save(customer);
	}
	
	
	
}
