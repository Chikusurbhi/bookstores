package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IReviewDao;
import com.cg.model.Book;
import com.cg.model.Customer;
import com.cg.model.Review;

@Service("iReviewService")
public class IReviewServiceImpl implements IReviewService {

	@Autowired
	IReviewDao iReviewDao;

	@Override
	public Review findByBook(Book book) {
		// TODO Auto-generated method stub
		if(iReviewDao.findByBook(book)!=null) {
		 return iReviewDao.findByBook(book);
		}else { 
			return null; 
		}
	}

	@Override
	public Review findByCustomer(Customer customer) {
		// TODO Auto-generated method stub
		if(iReviewDao.findByCustomer(customer)!=null) {
			return iReviewDao.findByCustomer(customer);
		}else {
			return null;
		}
	}
	
	public Review save(Review review) {
		return iReviewDao.save(review);
	}
	
	
}
