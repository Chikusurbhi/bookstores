package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IReviewDao;
import com.cg.model.Book;
import com.cg.model.Customer;
import com.cg.model.Review;

@Service
public class IReviewServiceImpl implements IReviewService {

	@Autowired
	IReviewDao iReviewDao;

	@Override
	public Review findByBook(Book book) {
		// TODO Auto-generated method stub
		return iReviewDao.findByBook(book);
	}

	@Override
	public Review findByCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return iReviewDao.findByCustomer(customer);
	}
}
