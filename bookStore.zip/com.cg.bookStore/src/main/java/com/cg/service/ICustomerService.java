package com.cg.service;

import com.cg.model.Customer;

public interface ICustomerService {

	public Customer findByCustomerId(int customerId);
	
	public Customer findByEmailId(String emailId);
	
}
