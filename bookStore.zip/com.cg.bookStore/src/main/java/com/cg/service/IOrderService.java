package com.cg.service;

import com.cg.model.Customer;
import com.cg.model.Order;

public interface IOrderService {
	public Order findByOrderId(int orderId);
	
	public Order findByCustomer(Customer customer);
	public Order save(Order order);
}
