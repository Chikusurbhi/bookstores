package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookDao;
import com.cg.model.Book;
import com.cg.model.Category;

@Service
public class  IBookServiceImpl implements IBookService{

	@Autowired
	IBookDao iBookDao;

	@Override
	public Book findByBookId(int bookId) {
		// TODO Auto-generated method stub
		return iBookDao.findByBookId(bookId);
	}

	@Override
	public List<Book> findByCategory(Category category) {
		// TODO Auto-generated method stub
		return iBookDao.findByCategory(category);
	}
	
}
