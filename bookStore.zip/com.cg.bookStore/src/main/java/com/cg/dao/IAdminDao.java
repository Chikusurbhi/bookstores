package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.model.Admin;

@Repository("iAdminDao")
public interface IAdminDao extends JpaRepository<Admin,Integer>{
	
  public Admin findByEmail(String email);
  
}
