package com.cg.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class BookController {

	
	@RequestMapping(value="all")
	public ModelAndView start1()
	{
		ModelAndView andView=new ModelAndView();
		andView.setViewName("home");
		andView.addObject("msg", "done");
		return andView;
	}
	
	
	
}
